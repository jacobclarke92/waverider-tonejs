//
//  ControllerBCF2000.h
//  BCF2000
//
//  Created by Joe Lambert on 27/07/2007.
//  Copyright 2007 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "Controller.h"

@interface Controller (ControllerBCF2000)

- (void)storeEncoderPresets;
- (void)readEncoderPresets;
- (void)setupForQuartz;

@end
