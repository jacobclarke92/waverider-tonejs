//
//  NumberHash.h
//  BCF2000
//
//  Created by Joe Lambert on 26/07/2007.
//  Copyright 2007 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface NSObject (NumberHash)

- (NSNumber *)hashNum;

@end
